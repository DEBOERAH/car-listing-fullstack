import React from 'react'
import BButton from './shared/BButton'

const Login = () => {
  return (
    <div>
      <h1>Login</h1>


      <div>
        <BButton bgcolor='red'>Login</BButton>
      </div>
    </div>
  )
}

export default Login