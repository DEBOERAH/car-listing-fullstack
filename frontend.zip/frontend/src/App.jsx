// import BButton from './components/shared/BButton'


// const App = () => {
//   //handle next
//   const handleNext = () => {
    
//     alert('next clicked')

//   }
//   //handle sell
//   const handleSell = () => {
    
//     alert('sell clicked')
//   }
//   //handle buy
//   const handleBuy = () => {
    
//     alert('buy clicked')
//   }
//   //handle signup
//   const handleSignup = () => {
    
//     alert('signup clicked')
//   }
//   return (
//     <div>
//       <h1>Car listing Bay</h1>

//       <div>
//         <BButton  btnFunc={handleSell} bradius={'10px'} bgColor="orange"><i className="fa-solid fa-arrow-right"></i>SELL</BButton>
//         <BButton   btnFunc={handleNext} bradius='0px'>NEXT <i className="fa-solid fa-arrow-left"></i></BButton>
//         <BButton btnFunc={handleBuy} bgColor='red'>READ</BButton>  
//         <BButton bgColor='green'>Buy</BButton>
//         <BButton/>
//         <BButton  btnFunc={handleSignup} bgColor='pink'>Login</BButton>
//         <BButton/>
//       </div>
//       <div>
//         <BButton btnName="activeBtn">submit form</BButton>
//         <BButton btnName="inactiveBtn">submit form</BButton>
//       </div>
//     </div>
//   )
// }

// export default App

import React from 'react'
import Counter from './components/counter/counter'
import Login from './components/Login'
import BButton from './components/shared/BButton'
import { useState } from 'react'
import Imagegallery from './components/Imagegallery'


const App = () => {
  return (
    <div>
      
    <h1>carlistingbay</h1>
    <Login></Login>
    <Counter/>

    <BButton bgColor={'red'}> Logout</BButton>
    <Imagegallery></Imagegallery>
    </div>
    
  )
}

export default App